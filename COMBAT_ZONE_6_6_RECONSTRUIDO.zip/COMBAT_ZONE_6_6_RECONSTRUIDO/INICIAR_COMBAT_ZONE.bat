@echo off
cd /d "%~dp0"
title COMBAT ZONE 6.6
where powershell >nul 2>nul
if errorlevel 1 (echo Windows PowerShell no esta disponible. & pause & exit /b 1)
start "COMBAT ZONE servidor" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8765
echo Si el navegador no abre, visita http://127.0.0.1:8765
echo No cierres la ventana del servidor mientras juegas.
pause
