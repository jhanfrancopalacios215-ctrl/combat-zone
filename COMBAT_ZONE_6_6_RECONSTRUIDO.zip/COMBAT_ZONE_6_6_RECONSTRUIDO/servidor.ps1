$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 8765)
try { $listener.Start() } catch { Write-Host 'No se pudo abrir el puerto 8765. Cierra otra instancia del juego.' -ForegroundColor Red; Read-Host 'Enter para salir'; exit 1 }
Write-Host 'COMBAT ZONE 6.6 activo en http://127.0.0.1:8765' -ForegroundColor Green
Write-Host 'Deja esta ventana abierta mientras juegas.' -ForegroundColor Yellow
while ($listener.Server.IsBound) {
  $client = $listener.AcceptTcpClient(); $stream = $client.GetStream(); $reader = [System.IO.StreamReader]::new($stream)
  $line = $reader.ReadLine(); if (!$line) { $client.Close(); continue }; $parts = $line.Split(' '); $url = [Uri]::UnescapeDataString($parts[1].Split('?')[0]);
  while (($h=$reader.ReadLine()) -ne '') { if ($null -eq $h) { break } }
  if ($url -eq '/') { $url='/index.html' }
  $relative = $url.TrimStart('/').Replace('/', [IO.Path]::DirectorySeparatorChar); $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
  if (!$path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or !(Test-Path -LiteralPath $path -PathType Leaf)) { $body=[Text.Encoding]::UTF8.GetBytes('404 Not Found'); $status='404 Not Found'; $type='text/plain' }
  else { $body=[IO.File]::ReadAllBytes($path); $status='200 OK'; $ext=[IO.Path]::GetExtension($path).ToLowerInvariant(); $type=switch($ext){'.html'{'text/html; charset=utf-8'}'.js'{'text/javascript'}'.css'{'text/css'}'.glb'{'model/gltf-binary'}'.obj'{'text/plain'}'.txt'{'text/plain; charset=utf-8'}default{'application/octet-stream'}} }
  $head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nAccess-Control-Allow-Origin: *`r`nConnection: close`r`n`r`n"); $stream.Write($head,0,$head.Length); $stream.Write($body,0,$body.Length); $client.Close()
}
